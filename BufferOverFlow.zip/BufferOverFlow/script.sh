 #! /bin/sh
g++ question.cpp -o prg
./prg < inp
